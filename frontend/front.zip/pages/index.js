﻿import { useEffect, useRef, useState } from 'react'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8888'
const UNREACHABLE = 'Backend is not reachable. Please make sure FastAPI is running on port 8888.'

const createMessage = (role, content, sources = []) => ({ id: String(Date.now()) + Math.random(), role, content, sources, loading: false })
const errorText = (error) => error instanceof TypeError ? UNREACHABLE : (error.message || 'Something went wrong. Please try again.')

export default function Home() {
  const [messages, setMessages] = useState([])
  const [question, setQuestion] = useState('')
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [selectedFile, setSelectedFile] = useState(null)
  const [error, setError] = useState('')
  const [uploadMessage, setUploadMessage] = useState('')
  const [knowledge, setKnowledge] = useState(null)
  const [knowledgeError, setKnowledgeError] = useState(false)
  const [conversations, setConversations] = useState([])
  const [documents, setDocuments] = useState([])
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const fileRef = useRef(null)
  const endRef = useRef(null)
  const get = async (path) => { const r = await fetch(API_URL + path); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.detail || 'Request failed'); return d }
  const refreshKnowledge = async () => { try { setKnowledge(await get('/knowledge')); setKnowledgeError(false) } catch { setKnowledgeError(true) } }
  const refreshHistory = async () => { const r = await Promise.allSettled([get('/conversations'), get('/documents')]); if (r[0].status === 'fulfilled') setConversations(r[0].value.slice(0, 5)); if (r[1].status === 'fulfilled') setDocuments(r[1].value.slice(0, 5)) }
  useEffect(() => { refreshKnowledge(); refreshHistory() }, [])
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages])
  const ask = async (event) => { event.preventDefault(); const text = question.trim(); if (!text) return setError('Please enter a question.'); const user = createMessage('user', text); const pending = { ...createMessage('assistant', 'Thinking...'), loading: true }; setMessages((m) => [...m, user, pending]); setQuestion(''); setError(''); setLoading(true); try { const r = await fetch(API_URL + '/ask', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: text }) }); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.detail || 'Unable to get an answer.'); setMessages((m) => m.map((x) => x.id === pending.id ? { ...x, content: d.answer, sources: d.sources || [], loading: false } : x)); refreshHistory() } catch (e) { setMessages((m) => m.filter((x) => x.id !== pending.id)); setError(errorText(e)) } finally { setLoading(false) } }
  const chooseFile = (event) => { const file = event.target.files?.[0]; if (!file) return; if (!file.name.toLowerCase().endsWith('.txt')) { event.target.value = ''; return setError('Only .txt files are supported.') } setSelectedFile(file); setError(''); setUploadMessage('') }
  const upload = async () => { if (!selectedFile) return setError('Please choose a .txt file to upload.'); setUploading(true); setError(''); try { const form = new FormData(); form.append('file', selectedFile); const r = await fetch(API_URL + '/upload', { method: 'POST', body: form }); const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.detail || 'Unable to upload the document.'); setUploadMessage(d.message || 'Document uploaded and indexed successfully.'); setSelectedFile(null); fileRef.current.value = ''; await Promise.all([refreshKnowledge(), refreshHistory()]) } catch (e) { setError(errorText(e)) } finally { setUploading(false) } }
  const openHistory = (item) => setMessages((m) => [...m, createMessage('user', item.question), createMessage('assistant', item.response, Array.isArray(item.sources) ? item.sources : [])])
  return <main className={sidebarCollapsed ? "app sidebar-collapsed" : "app"}><aside><button type="button" className="sidebar-toggle" onClick={() => setSidebarCollapsed((value) => !value)} aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}>{sidebarCollapsed ? "+" : "-"}</button><div className="sidebar-body"><div className="brand"><b>RF</b><div><strong>RAG FAQ Bot</strong><small>Grounded answers</small></div></div><button type="button" className="new" onClick={() => { setMessages([]); setQuestion(''); setError('') }}>+ New Chat</button><section><label>Knowledge file</label><input ref={fileRef} id="file" type="file" accept=".txt" onChange={chooseFile} /><p>{selectedFile?.name || 'Choose a .txt file'}</p><button type="button" onClick={upload} disabled={!selectedFile || uploading}>{uploading ? 'Uploading...' : 'Upload document'}</button>{uploadMessage && <em>{uploadMessage}</em>}</section><section><label>Knowledge status</label>{knowledgeError ? <p>Knowledge status unavailable</p> : <><b>{knowledge?.chunks_indexed ?? '--'} chunks</b><p>{knowledge?.active_sources?.join(', ') || 'No active source'}</p></>}</section><section className="scrollable-history"><label>Recent questions</label>{conversations.length ? conversations.map((x) => <button className="history" key={x.id} onClick={() => openHistory(x)}>{x.question}</button>) : <p>No saved questions yet</p>}</section><section className="scrollable-history"><label>Recent documents</label><div className="documents-list">{documents.length ? documents.map((x) => <p key={x.id}>{x.filename} · {x.chunks_created} chunks</p>) : <p>No uploaded documents yet</p>}</div></section></div></aside><div className="chat"><header><div><small>RAG assistant</small><h1>Ask questions from your uploaded document</h1></div><span>{knowledge?.active_sources?.length ? 'Knowledge ready' : 'Waiting for a document'}</span></header><div className="scroll">{!messages.length && <div className="empty"><h2>Start a grounded conversation</h2><p>Upload a text file, then ask a question. Every answer includes the source chunks used.</p></div>}{messages.map((m) => <article className={m.role} key={m.id}><b>{m.role === 'user' ? 'You' : 'AI'}</b><div><small>{m.role === 'user' ? 'You' : 'RAG FAQ Bot'}</small><p>{m.content}</p>{m.role === 'assistant' && !m.loading && (m.sources.length ? <details><summary>Sources used ({m.sources.length})</summary>{m.sources.map((s) => <div className="source" key={s.chunk_id}><b>Chunk {s.chunk_id}</b><span>{s.text}</span></div>)}</details> : <em>No source chunks found.</em>)}</div></article>)}<div ref={endRef} /></div><footer>{error && <div className="error">{error}</div>}<form onSubmit={ask}><textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Ask something about your knowledge file..." rows={1} /><button disabled={loading || !question.trim()}>{loading ? 'Thinking...' : 'Send'}</button></form></footer></div></main>
}




